package com.example.week4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
