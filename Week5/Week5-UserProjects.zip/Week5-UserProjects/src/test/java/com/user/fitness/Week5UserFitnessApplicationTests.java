package com.user.fitness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5UserFitnessApplicationTests {

	@Test
	void contextLoads() {
	}

}
