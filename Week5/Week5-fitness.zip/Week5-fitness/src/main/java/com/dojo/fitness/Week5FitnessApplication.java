package com.dojo.fitness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5FitnessApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week5FitnessApplication.class, args);
	}

}
