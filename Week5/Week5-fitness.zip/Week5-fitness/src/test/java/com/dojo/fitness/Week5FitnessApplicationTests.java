package com.dojo.fitness;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5FitnessApplicationTests {

	@Test
	void contextLoads() {
	}

}
